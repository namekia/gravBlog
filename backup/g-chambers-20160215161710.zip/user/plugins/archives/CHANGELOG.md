# v1.4.0
## 01/06/2016

1. [](#improved)
    * Allow for translated months
1. [](#bugfix)
    * Fix blueprints by adding the category to filters

# v1.3.0
## 08/25/2015

1. [](#improved)
    * Added blueprints for Grav Admin plugin

# v1.2.1
## 02/19/2015

2. [](#improved)
    * Implemented new `param_sep` variable from Grav 0.9.18

# v1.2.0
## 01/08/2015

1. [](#new)
    * Added new `archives_year` automatic taxonomy type
2. [](#improved)
    * Automatically adds taxonomy types (`archives_month`, `archives_year`) rather than requiring you to manually edit `site.yaml`

# v1.10
## 11/30/2014

1. [](#new)
    * ChangeLog started...
