---
title: GSAP animation
blog_url: blog
banner: walk1600.jpg
body_classes: header-image fullwidth

sitemap:
    changefreq: monthly
    priority: 1.03

content:
    items: @self.children
    order:
        by: date
        dir: desc
    limit: 5
    pagination: true

feed:
    description: Sample Blog Description
    limit: 10

#pagination: true

assets:
  enabled: true
---

### Movement and Interaction Notes
