# v1.1.0
## 12/11/2015

1. [](#new)
	* Added some redirect examples
1. [](#improved)
    * removed deprecated `markdown_extra` setting

# v1.0.1
## 01/23/2015

1. [](#improved)
    * Added a sample "Daring Fireball" style link page

# v1.0.0
## 12/21/2014

1. [](#improved)
    * Updated with Antimatter Theme v1.2.6
    * Updated with SimpleSearch Plugin v1.2.2

# v0.9.10
## 12/12/2014

1. [](#new)
    * ChangeLog started...
