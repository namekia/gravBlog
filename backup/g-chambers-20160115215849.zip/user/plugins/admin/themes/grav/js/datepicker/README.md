# Custom build of kendo-ui-core

Compiled by: Gert
Source: https://github.com/telerik/kendo-ui-core

## How to reproduce

1. Checkout source
2. npm install
3. grunt custom:datepicker,datetimepicker
4. Copy `kendo.custom.min.js` from `dist` folder
