<?php
 namespace Grav\Theme;

 class Mytheme extends Antimatter
 {
     // Some new methods, properties etc.
 }
?>
