---
title: Home
menu: Home
blog_url: home
banner: blueVan3600x560.jpg
body_classes: header-image fullwidth

template: blog

sitemap:
    changefreq: monthly
    priority: 1.03

content:
    items:
        '@taxonomy.category': blog
    order:
        by: date
        dir: desc
    limit: 2
    pagination: false

feed:
    description: Sample Blog Description
    limit: 10

pagination: true
---

# Greg&rsquo;s Sandbox
## Notes and Observations &mdash; Grav CMS
