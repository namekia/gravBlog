---
title: Simple CSS Image Slider
date: 15:35 01/25/2016
author: Gregory Chambers
summary:
  enabled: true
  size: 0
taxonomy:
    category: blog
    tag: [images, cookbook]
---

Cookbook tutorial for a CSS image slider containing four images. Relies on the
jQuery plug-in named "Slidy". Rather crude, but it does seem to work with minimal set up... just some keyframe rules in the `_custom.scss` file.

Perhaps it might be worthwhile to explore the GSAP version of this technique? Definetly, but I'll need to wait until I have more skills to tackle that project. Reference files for GSAP technique are found at:

```
C:\Users\Gregory Chambers\_gProjects\GSAP_Instruction\gregGSAP_Class\Image Slider
```



Start by placing the images into this folder.
