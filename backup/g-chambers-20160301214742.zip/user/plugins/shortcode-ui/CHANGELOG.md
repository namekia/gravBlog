# v2.0.0
## 02/11/2016

1. [](#improved)
    * Refactored to work with `shortcode-core` v2.0.0

# v1.0.1
## 01/18/2016

1. [](#improved)
    * Added a 'shortcode-core' dependency

# v1.0.0
## 01/18/2016

1. [](#new)
    * ChangeLog started...
