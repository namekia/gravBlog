# v2.5.0
## 02/05/2016

1. [](#new)
    * Added custom overrides for SmartyPants default quotes

# v2.4.0
## 12/30/2015

1. [](#improved)
    * Renamed initial event for more reliable operation

# v2.3.0
## 08/25/2015

1. [](#improved)
    * Added blueprints for Grav Admin plugin
    * Added page-level smartypants options

# v2.2.0
## 07/21/2015

2. [](#improved)
    * Changed the initialization even to `onBuildPagesInitialized`
    * Added compatibility note in the `README.md` file
    
# v2.1.0
## 02/22/2015

2. [](#improved)
    * Uses new `mergeConfig()` method provided in base Plugins class

# v2.0.1
## 11/30/2014

1. [](#new)
    * ChangeLog started...
