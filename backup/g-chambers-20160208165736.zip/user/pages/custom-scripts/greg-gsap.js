// MDN: The DOMContentLoaded event is fired when the initial HTML document has been completely loaded and parsed, without waiting for stylesheets and images to finish loading -->
// document.addEventListener("DOMContentLoaded", function(event) {
//         "use strict";
//             var play = document.getElementById('btn');
//             var tl;

//         tl = new TimelineLite({paused: true});
//         tl.to('.circ', 2.0, {
//             x: 600
//         });
//         // Use native GSAP progress, play and restart methods
//         play.addEventListener('click', function() {
//             if (tl.progress() < 1) {
//                 tl.play();
//             } else {
//                 tl.restart();
//             }
//         }, false);
// });


