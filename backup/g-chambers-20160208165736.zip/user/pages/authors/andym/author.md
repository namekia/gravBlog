---
name: Andy M
email: info@getgrav.org
website: http://getgrav.org
routable: false
taxonomy:
    author: andym
---

Andy lives on the precarious edge of *development* and *design*.  He is passionate about anything and everything that makes technology accessible to more people. He envisioned *Grav* as an easy way to create web sites without requiring the learning curve of traditional full-size CMS alternatives.
