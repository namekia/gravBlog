---
title: Home
blog_url: blog
banner: playground1200.jpg
body_classes: header-image fullwidth

sitemap:
    changefreq: monthly
    priority: 1.03

content:
    items:
        '@taxonomy.category': blog
    order:
        by: date
        dir: desc
    limit: 2
    pagination: false

feed:
    description: Sample Blog Description
    limit: 10

pagination: true
---

# Greg&rsquo;s Sandbox
## Notes and Observations &mdash; Grav CMS
